"""Hand-built positive control: two-call schema-linking — call 1 lists relevant tables/columns, call 2 writes SQL from the linked subset."""
from ..harness_base import SQLHarness
from .. import bridge

SYS_LINK = ("You are a schema-linking expert. Given a SQLite schema and a question, list ONLY the "
            "tables and columns needed to answer it, plus the join keys. Be terse.")
SYS_SQL = ("You are an expert Text-to-SQL system for SQLite. Use ONLY the linked schema below. "
           "Output exactly one SQLite query inside a ```sql block.")


class HpcSchema(SQLHarness):
    def solve(self, question: str) -> str:
        link = self.llm(f"SQLite schema:\n{self.schema}\n\nQuestion: {question}\n\nList the needed tables, columns and join keys.",
                        system=SYS_LINK, temperature=0.0)
        prompt = (f"Linked schema (authoritative):\n{link}\n\nFull schema for reference:\n{self.schema}\n\n"
                  f"Question: {question}\n\nWrite the SQLite query.")
        return bridge.extract_sql(self.llm(prompt, system=SYS_SQL, temperature=0.0))
