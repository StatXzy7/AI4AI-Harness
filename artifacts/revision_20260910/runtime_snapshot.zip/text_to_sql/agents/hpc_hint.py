"""Hand-built positive control: evidence/hint-first — restate the question's Hint constraints as hard requirements before writing SQL."""
from ..harness_base import SQLHarness
from .. import bridge

SYS = ("You are an expert Text-to-SQL system for SQLite. The Hint line contains external knowledge "
       "that MUST be reflected in the query. Output exactly one SQLite query inside a ```sql block.")


class HpcHint(SQLHarness):
    def solve(self, question: str) -> str:
        base, _, hint = question.partition("Hint:")
        hint = hint.strip() or "(no hint)"
        prompt = (f"Database schema:\n{self.schema}\n\nQuestion: {base.strip()}\n\n"
                  f"Hint (external knowledge, treat as binding constraints):\n{hint}\n\n"
                  f"Restate the hint's constraints, then write the SQLite query that satisfies them.")
        return bridge.extract_sql(self.llm(prompt, system=SYS, temperature=0.0))
