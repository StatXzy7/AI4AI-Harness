"""NEGATIVE CONTROL: unconditionally issues a second generation call and returns it. It never
reads the execution result, so it is NOT conditional repair -- but it mimics one superficially."""
from ..harness_base import SQLHarness
from .. import bridge


class NegUncondTwocall(SQLHarness):
    def solve(self, question: str) -> str:
        p = f"Schema:\n{self.schema}\n\nQuestion:\n{question}\nReturn only SQL."
        first = bridge.extract_sql(self.llm(p)).strip()
        self.execute(first)                      # executes, but ignores the outcome entirely
        second = bridge.extract_sql(self.llm(p + "\n\nTry again.")).strip()
        return second or first
