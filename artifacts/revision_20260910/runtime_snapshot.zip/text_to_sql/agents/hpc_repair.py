"""Hand-built positive control: generate -> execute -> feed execution errors back for repair (up to 2 rounds)."""
from ..harness_base import SQLHarness
from .. import bridge

SYS = ("You are an expert Text-to-SQL system for SQLite. Output exactly one SQLite query "
       "inside a ```sql block. No commentary.")


class HpcRepair(SQLHarness):
    def solve(self, question: str) -> str:
        prompt = f"Database schema:\n{self.schema}\n\nQuestion: {question}\n\nWrite the SQLite query."
        sql = bridge.extract_sql(self.llm(prompt, system=SYS, temperature=0.0))
        for _ in range(2):
            if not sql.strip():
                break
            r = self.execute(sql)
            if r.get("ok"):
                return sql
            err = str(r.get("error") or r)[:400]
            prompt = (f"Database schema:\n{self.schema}\n\nQuestion: {question}\n\n"
                      f"Your previous query:\n{sql}\n\nIt failed with error:\n{err}\n\n"
                      f"Write a corrected SQLite query.")
            sql = bridge.extract_sql(self.llm(prompt, system=SYS, temperature=0.0))
        return sql
