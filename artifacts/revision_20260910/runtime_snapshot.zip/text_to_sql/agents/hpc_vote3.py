"""Hand-built positive control: 3 independent samples at temperature 0.7, execute all, return the first whose execution succeeds (prefer majority rows)."""
from ..harness_base import SQLHarness
from .. import bridge
from collections import Counter
from ..resultkey import result_key

SYS = ("You are an expert Text-to-SQL system for SQLite. Output exactly one SQLite query "
       "inside a ```sql block. No commentary.")


class HpcVote3(SQLHarness):
    def solve(self, question: str) -> str:
        prompt = f"Database schema:\n{self.schema}\n\nQuestion: {question}\n\nWrite the SQLite query."
        outs = self.llm(prompt, system=SYS, temperature=0.7, n=3)
        cands = [bridge.extract_sql(o) for o in (outs if isinstance(outs, list) else [outs])]
        cands = [c for c in cands if c and c.strip()]
        results = []
        for c in cands:
            r = self.execute(c)
            results.append((c, r))
        ok = [(c, r) for c, r in results if r.get("ok")]
        if not ok:
            return cands[0] if cands else ""
        keys = [result_key(r["rows"], True) for _, r in ok]
        top = Counter(keys).most_common(1)[0][0]
        for (c, r), k in zip(ok, keys):
            if k == top:
                return c
        return ok[0][0]
