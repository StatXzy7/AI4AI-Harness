"""NEGATIVE CONTROL: draws 3 samples then returns the FIRST one. Looks like voting in a trace
(3 samples, 3 executions) but performs no selection."""
from ..harness_base import SQLHarness
from .. import bridge


class NegSelectfirst(SQLHarness):
    def solve(self, question: str) -> str:
        p = f"Schema:\n{self.schema}\n\nQuestion:\n{question}\nReturn only SQL."
        outs = self.llm(p, temperature=0.7, n=3)
        cands = [bridge.extract_sql(o).strip() for o in (outs if isinstance(outs, list) else [outs])]
        for c in cands:
            self.execute(c)
        return cands[0]
